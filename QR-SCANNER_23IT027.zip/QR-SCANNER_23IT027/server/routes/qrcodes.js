const express = require('express');
const router = express.Router();
const QRCode = require('../models/QRCode');
const auth = require('../middleware/auth');
const qrcode = require('qrcode');
const nodemailer = require('nodemailer');
const path = require('path');
const fs = require('fs');

// Create QR Code
router.post('/', auth, async (req, res) => {
    try {
        const { text } = req.body;
        
        // Generate QR Code
        const qrCodeData = await qrcode.toDataURL(text);
        
        // Create QR Code document
        const qrCode = new QRCode({
            text,
            userId: req.user._id,
            imageUrl: qrCodeData
        });
        
        await qrCode.save();
        
        res.status(201).json(qrCode);
    } catch (error) {
        res.status(500).json({ message: 'Error generating QR code', error: error.message });
    }
});

// Get all QR Codes with pagination and filtering
router.get('/', auth, async (req, res) => {
    try {
        const { page = 1, limit = 10, startDate, endDate } = req.query;
        
        const query = { userId: req.user._id };
        
        // Add date range filter if provided
        if (startDate && endDate) {
            query.generatedAt = {
                $gte: new Date(startDate),
                $lte: new Date(endDate)
            };
        }
        
        const qrCodes = await QRCode.find(query)
            .sort({ generatedAt: -1 })
            .skip((page - 1) * limit)
            .limit(parseInt(limit));
            
        const total = await QRCode.countDocuments(query);
        
        res.json({
            qrCodes,
            totalPages: Math.ceil(total / limit),
            currentPage: page
        });
    } catch (error) {
        res.status(500).json({ message: 'Error fetching QR codes', error: error.message });
    }
});

// Delete QR Code
router.delete('/:id', auth, async (req, res) => {
    try {
        const qrCode = await QRCode.findOneAndDelete({
            _id: req.params.id,
            userId: req.user._id
        });
        
        if (!qrCode) {
            return res.status(404).json({ message: 'QR Code not found' });
        }
        
        res.json({ message: 'QR Code deleted successfully' });
    } catch (error) {
        res.status(500).json({ message: 'Error deleting QR code', error: error.message });
    }
});

// Share QR Code via email
router.post('/:id/share', auth, async (req, res) => {
    try {
        const { email } = req.body;
        const qrCode = await QRCode.findOne({
            _id: req.params.id,
            userId: req.user._id
        });
        
        if (!qrCode) {
            return res.status(404).json({ message: 'QR Code not found' });
        }
        
        // Create email transporter
        const transporter = nodemailer.createTransport({
            service: 'gmail',
            auth: {
                user: process.env.EMAIL_USER,
                pass: process.env.EMAIL_PASS
            }
        });
        
        // Send email
        await transporter.sendMail({
            from: process.env.EMAIL_USER,
            to: email,
            subject: 'Shared QR Code',
            html: `
                <h1>QR Code Shared with You</h1>
                <p>Here is the QR Code that was shared with you:</p>
                <img src="${qrCode.imageUrl}" alt="QR Code" />
                <p>Text content: ${qrCode.text}</p>
            `
        });
        
        res.json({ message: 'QR Code shared successfully' });
    } catch (error) {
        res.status(500).json({ message: 'Error sharing QR code', error: error.message });
    }
});

module.exports = router; 